ps -ef|grep "go-fly"
kill -9 $(pidof 'go-fly')