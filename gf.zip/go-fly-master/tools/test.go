package tools

func MyPointer() {

}
