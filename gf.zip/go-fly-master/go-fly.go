package main

import (
	"github.com/taoshihan1991/imaptool/cmd"
)

func main() {
	cmd.Execute()
}
