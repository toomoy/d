#!/bin/bash

# 重启计划任务
service cron restart

# 如果你开发环节挂载目录下太多文件，会导致chown慢，建议注释；生产环境请取消注释或者第一次进入容器自行命令一次.
# chown -R www-data:www-data /var/log/www && chown -R www-data:www-data /var/www

php-fpm -D
/usr/bin/supervisord -n -c /etc/supervisor/supervisord.conf
