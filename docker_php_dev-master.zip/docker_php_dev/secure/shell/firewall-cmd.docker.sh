#!/bin/bash
set -e

# 清空防火墙命令
# iptables -P INPUT ACCEPT
# iptables -F
# iptables-save > /etc/iptables/iptables

# systemctl stop docker
# systemctl start docker
# systemctl stop firewalld
# systemctl start firewalld

# 内网
# firewall-cmd --permanent --zone=trusted --add-source="172.17.0.0/16"
# firewall-cmd --permanent --zone=trusted --add-source="172.16.0.0/16"
# firewall-cmd --permanent --zone=trusted --add-source="172.33.1.0/16"

# 外网
# firewall-cmd --permanent --zone=trusted --add-source="47.56.144.242"
# firewall-cmd --permanent --zone=trusted --add-source="156.226.16.149"
# firewall-cmd --permanent --zone=trusted --add-source="156.226.16.162"
# firewall-cmd --permanent --zone=trusted --add-source="156.226.16.163"
# firewall-cmd --permanent --zone=trusted --add-source="156.226.16.164"
# firewall-cmd --permanent --zone=trusted --add-source="139.180.128.226"
# firewall-cmd --permanent --zone=trusted --add-source="198.44.250.198"
# firewall-cmd --permanent --zone=trusted --add-source="103.87.8.176"
# firewall-cmd --permanent --zone=trusted --add-source="45.76.150.237"
# firewall-cmd --permanent --zone=trusted --add-source="45.119.97.132"
# firewall-cmd --permanent --zone=trusted --add-source="47.56.69.237"
# firewall-cmd --permanent --zone=trusted --add-source="45.118.132.110"
# firewall-cmd --permanent --zone=trusted --add-source="103.84.90.156"
# firewall-cmd --permanent --zone=trusted --add-source="103.214.142.103"
# firewall-cmd --permanent --zone=trusted --add-source="192.74.224.171"
# firewall-cmd --permanent --zone=trusted --add-source="45.119.97.73"
# firewall-cmd --permanent --zone=trusted --add-source="47.52.249.150"
# firewall-cmd --permanent --zone=trusted --add-source="156.226.16.151"
# firewall-cmd --permanent --zone=trusted --add-source="156.226.16.150"

# [start] docker 规则
firewall-cmd --permanent --direct --remove-chain ipv4 filter DOCKER-USER
firewall-cmd --permanent --direct --remove-rules ipv4 filter DOCKER-USER
firewall-cmd --permanent --direct --add-chain ipv4 filter DOCKER-USER

firewall-cmd --permanent --direct --add-rule ipv4 filter DOCKER-USER 0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT -m comment --comment "This allows docker containers to connect to the outside world"

firewall-cmd --permanent --direct --add-rule ipv4 filter DOCKER-USER 0 -j ACCEPT -s 172.17.0.0/16 -m comment --comment "allow internal docker communication"
firewall-cmd --permanent --direct --add-rule ipv4 filter DOCKER-USER 0 -j ACCEPT -s 172.16.0.0/16 -m comment --comment "allow internal docker communication"
firewall-cmd --permanent --direct --add-rule ipv4 filter DOCKER-USER 0 -j ACCEPT -s 172.33.1.0/16 -m comment --comment "allow internal docker communication"

 # 直接允許來自特定 IP 的所有流量
firewall-cmd --permanent --direct --add-rule ipv4 filter DOCKER-USER 0 -j ACCEPT -s 45.76.150.237/32 -m comment --comment "allow come from special ip"
firewall-cmd --permanent --direct --add-rule ipv4 filter DOCKER-USER 0 -j ACCEPT -s 47.56.69.237/32 -m comment --comment "allow come from special ip"

# 这个一定要在最后一行添加！！！！
firewall-cmd --permanent --direct --add-rule ipv4 filter DOCKER-USER 0 -j REJECT -m comment --comment "reject all other traffic"
# [end] docker 规则

firewall-cmd --reload