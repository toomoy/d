#  Docker化PHP环境

执行下面命令，创建创建一个docker 网络桥，注意网段和桥名字，后面.env里会用到其配置
```
docker network create -d bridge --subnet 172.33.1.0/24 my_net_dev
# consul网桥专供于Consul服务, 不需要则无需创建.
docker network create -d bridge --subnet 172.33.2.0/24 my_net_consul
```
Windows下mongodb无法持久化，解决：先创建mongo_vol容器卷
```
docker volume create mongo_vol
```

# Docker 与防火墙冲突解决
\# 先修改/etc/sysconfig/network-script/ifcfg-eh0,加入 DNS1=x.x.x.x DNS2=x.x.x.x DNS3=x.x.x.x
\# vi /etc/docker/daemon.json
```
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://1o70e58r.mirror.aliyuncs.com",
    "https://registry.docker-cn.com"
  ],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "500m",
    "max-file": "5"
  },
  "dns": [
    "1.0.0.1",
    "8.8.8.8",
    "223.5.5.5"
  ],
  "iptables": true
}
```

## Docker-Compose 配置
复制配置文件
```
cp example.env .env
```

修改.env
```
LOCAL_WEB_PATH=
NETWORK_EXT_NAME=my_net_prod
IPV4_PREFIX=172.33.1.
MYSQL_ROOT_PASSWORD=FNl8EI4eZuTqB
```

docker-compose.yaml文件注释或者取消注释，根据所需docker service

## Nginx配置
nginx.conf 根据当前宿主机CPU数量配置 worker_processes

## 项目部署
```
# 配置.env
vi /var/www/.env

# php73 以supervisor为阻塞！ supervisor守护hyperf
# 配置hyperf启动路径
vi php/php73/supervisor/conf.d/hyperf_server.conf
```


## mysql 从库
从库连接到主库，获取到二进制日志后重放。这里首先要配置上面创建的账号进行连接，使用命令进行相应的设置。
```
CHANGE MASTER TO 
MASTER_HOST = 'xx.xx.xx.xxx',
MASTER_PORT = 3306,
MASTER_USER = 'user_log',
MASTER_PASSWORD = 'user_password',
MASTER_LOG_FILE = 'mysql-bin.000006';
MASTER_LOG_POS = 582;
```